<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StringAnswerTest extends Model
{
    //
}
