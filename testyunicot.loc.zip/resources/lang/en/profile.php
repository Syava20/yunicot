<?php
return [

    'logout' => 'Logout',
];