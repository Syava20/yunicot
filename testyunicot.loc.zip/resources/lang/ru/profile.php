<?php
return [

    'logout' => 'Выход',
];