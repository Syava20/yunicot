@extends('layouts.app')

@section('content')
    Активация прошла успешно
@endsection