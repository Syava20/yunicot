@extends('layouts.app')

@section('content')
    На ваш email отправлено письмо с ссылкой для активации
@endsection