<!DOCTYPE html>
<html>
<head>
    <title>Yunicot - 404</title>
</head>
<body>
<p>You broke the balance of the internet</p>
</body>
</html>