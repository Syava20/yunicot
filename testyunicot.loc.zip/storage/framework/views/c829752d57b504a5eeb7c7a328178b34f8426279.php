<?php $__env->startSection('content'); ?>
    <p>Имя: <?php echo e(Auth::user()->firstName); ?></p>
    <p>Фамилия: <?php echo e(Auth::user()->lastName); ?></p>
    <p>Пол: <?php echo e(Auth::user()->sex == 0 ? 'Муж' : 'Жен'); ?></p>
    <p>Email: <?php echo e(Auth::user()->email); ?></p>
    <p><a href="<?php echo e(url('/'.Auth::user()->id.'/edit')); ?>">Редактировать</a></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>