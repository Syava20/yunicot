<?php $__env->startSection('content'); ?>
    На ваш email отправлено письмо с ссылкой для активации
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>